# Rudro Roy Portfolio

React + TypeScript + Vite. Ready for GitHub Pages.

## Publish on GitHub (easy steps)
1. On github.com click **New repository**. Name it, for example, `portfolio`. Keep it Public.
2. Click **uploading an existing file**. Upload ALL files from this folder, including the hidden `.github` folder (if upload skips it, use GitHub Desktop or `git push` instead).
3. Open **Settings > Pages**. Under **Source** choose **GitHub Actions**.
4. Open the **Actions** tab. Wait for "Deploy to GitHub Pages" to turn green (about 1 to 2 minutes).
5. Your site is live at `https://YOUR-USERNAME.github.io/portfolio/`.
Every time you push a change to the `main` branch, the site updates by itself.

## Run on your computer
`npm install` then `npm run dev`. To test the final build: `npm run build` then `npm run preview`.

## Edit your content
- `src/data/site.ts`: email, WhatsApp, Facebook, LinkedIn, availability label, optional form endpoint
- `src/data/projects.ts`: add real projects. Put images in `public/images/projects/`. The Portfolio section stays hidden until you add one real project (remove `placeholder: true`).
- `src/data/tools.ts`: keep only tools you really use
- `src/data/services.ts`: service cards
- Photos: `public/images/rudro-cutout.webp` (hero), `public/images/rudro-portrait.jpg` (About)

## Notes
- The contact form opens the visitor's email app. For a direct form, create a free form at formspree.io and paste its URL into `formEndpoint` in `src/data/site.ts`.
- For a social share image, add an absolute `og:image` URL in `index.html` after the site is live.
