// EDIT ME: replace each placeholder. Add a real image at public/images/projects/ and set image: '/images/projects/name.jpg'.
// Entries with `placeholder: true` are hidden from the site. For each real project: fill it in and delete `placeholder: true`.
// The Portfolio section and its menu link appear automatically once one real project exists.
export interface Project { title: string; category: string; description: string; image?: string; url?: string; placeholder?: boolean }
const d = 'Placeholder entry. Replace this with a short description of the real project, your role, and the outcome.'
export const projects: Project[] = [
  { title: 'Social Media Campaign', category: 'Social Media Marketing', description: d, placeholder: true },
  { title: 'Brand Visual Identity', category: 'Graphic Design', description: d, placeholder: true },
  { title: 'SEO & Lead Generation', category: 'Digital Marketing', description: d, placeholder: true },
  { title: 'AI-Powered Content', category: 'AI Content Creation', description: d, placeholder: true },
  { title: 'Personal Branding Design', category: 'Personal Branding', description: d, placeholder: true },
  { title: 'Content Strategy', category: 'Content Marketing', description: d, placeholder: true },
]
