// EDIT ME: personal details, contact info and copy. Leave a value as '' to show a "not added yet" placeholder.
export const site = {
  name: 'Rudro Roy',
  title: 'Digital Marketer & AI Expert',
  available: 'Available for Selected Projects', // set to '' to hide the label
  contact: {
    email: 'rudroroy1475@gmail.com',      // e.g. 'you@example.com'
    whatsapp: '+8801986309207',   // digits only with country code, e.g. '8801XXXXXXXXX'
    linkedin: '',   // full URL
    facebook: 'https://www.facebook.com/rudro.roy.1475',   // full URL
  },
  // Optional: a form service URL (Formspree, Getform, your own API). Receives JSON via POST.
  formEndpoint: '',
}
export const values = [
  { title: 'Strategic Thinking', text: 'Marketing decisions guided by business goals and audience needs.' },
  { title: 'Creative Execution', text: 'Content and visual communication designed to make brands stand out.' },
  { title: 'AI-Powered Efficiency', text: 'Using appropriate AI tools to streamline workflows and explore creative possibilities.' },
]
export const principles = ['Continuous Learning', 'Creative Problem-Solving', 'Long-Term Value']
export const steps = [
  { title: 'Discover', text: 'Understand the business, target audience, and objectives.' },
  { title: 'Strategize', text: 'Develop an appropriate marketing or content strategy.' },
  { title: 'Create', text: 'Execute the design, content, or marketing deliverables.' },
  { title: 'Optimize', text: 'Review performance and identify opportunities for improvement.' },
]
