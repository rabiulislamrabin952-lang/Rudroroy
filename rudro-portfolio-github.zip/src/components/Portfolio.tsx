import { useEffect, useRef, useState } from 'react'
import { projects } from '../data/projects'
export default function Portfolio() {
  const [sel, setSel] = useState<number | null>(null)
  const dlg = useRef<HTMLDialogElement>(null)
  useEffect(() => { const d = dlg.current; if (!d) return; if (sel !== null && !d.open) d.showModal(); if (sel === null && d.open) d.close() }, [sel])
  const shown = projects.filter(x => !x.placeholder)
  const p = sel !== null ? shown[sel] : null
  if (!shown.length) return null
  return (
    <section id="portfolio" className="sec alt">
      <div className="wrap">
        <div data-reveal><p className="label">SELECTED PROJECTS</p><h2>Work That Reflects My Approach.</h2></div>
        <ul className="grid3">
          {shown.map((x, i) => (
            <li key={x.title} data-reveal>
              <button className="proj" onClick={() => setSel(i)} aria-label={`Open details for ${x.title}`}>
                <span className="thumb" style={{ ['--h' as string]: `${230 + i * 14}` }}>
                  {x.image ? <img src={x.image} alt="" loading="lazy" /> : null}
                  {x.placeholder && <em>Placeholder</em>}
                </span>
                <span className="cat">{x.category}</span><strong>{x.title}</strong>
              </button>
            </li>))}
        </ul>
      </div>
      <dialog ref={dlg} className="modal" onClose={() => setSel(null)} onClick={e => { if (e.target === dlg.current) setSel(null) }} aria-labelledby="pt">
        {p && <div className="modal-in">
          <p className="cat">{p.category}</p><h3 id="pt">{p.title}</h3><p>{p.description}</p>
          <div className="row">{p.url && <a className="btn btn-sm" href={p.url} target="_blank" rel="noreferrer">View project</a>}
            <button className="btn btn-sm btn-ghost" onClick={() => setSel(null)}>Close</button></div>
        </div>}
      </dialog>
    </section>
  )
}
