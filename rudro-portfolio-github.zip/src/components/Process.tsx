import { steps } from '../data/site'
export default function Process() {
  return (
    <section className="sec">
      <div className="wrap">
        <div data-reveal><p className="label">HOW I WORK</p><h2>A Clear Process. A Focused Outcome.</h2></div>
        <ol className="steps">
          {steps.map((s, i) => <li key={s.title} data-reveal><span className="num">0{i + 1}</span><h3>{s.title}</h3><p>{s.text}</p></li>)}
        </ol>
      </div>
    </section>
  )
}
