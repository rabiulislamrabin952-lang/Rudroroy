import { useEffect, useRef } from 'react'
import { site } from '../data/site'
import { projects } from '../data/projects'
export default function Hero() {
  const stage = useRef<HTMLDivElement>(null)
  const hasWork = projects.some(p => !p.placeholder)
  useEffect(() => {
    const el = stage.current
    if (!el || matchMedia('(prefers-reduced-motion: reduce)').matches) return
    let raf = 0
    const move = (e: PointerEvent) => {
      cancelAnimationFrame(raf)
      raf = requestAnimationFrame(() => {
        const r = el.getBoundingClientRect()
        const x = Math.max(-1, Math.min(1, (e.clientX - r.left - r.width / 2) / window.innerWidth * 2))
        const y = Math.max(-1, Math.min(1, (e.clientY - r.top - r.height / 2) / window.innerHeight * 2))
        el.style.setProperty('--rx', `${-y * 5}deg`); el.style.setProperty('--ry', `${x * 9}deg`); el.style.setProperty('--tx', `${x * 16}px`)
      })
    }
    window.addEventListener('pointermove', move)
    return () => { window.removeEventListener('pointermove', move); cancelAnimationFrame(raf) }
  }, [])
  return (
    <section id="home" className="hero">
      <div className="glow" aria-hidden="true" />
      <div className="wrap hero-grid">
        <div className="hero-copy">
          <p className="label a1">DIGITAL MARKETING × AI</p>
          <h1 className="a2">Turning Digital<br />Ideas <span className="acc">Into Growth.</span></h1>
          <p className="lead a3">I'm Rudro Roy, a Digital Marketer &amp; AI Expert helping businesses strengthen their digital presence through strategic marketing, creative content, and AI-powered solutions.</p>
          <div className="row a4">
            <a className="btn" href="#contact">Work With Me</a>
            <a className="btn btn-ghost" href={hasWork ? '#portfolio' : '#services'}>{hasWork ? 'Explore My Work' : 'See My Services'}</a>
          </div>
          {site.available && <p className="avail a4"><i aria-hidden="true" />{site.available}</p>}
        </div>
        <div className="stage a5" ref={stage}>
          <span className="halo" aria-hidden="true" />
          <div className="float">
            <img className="cutout" src={`${import.meta.env.BASE_URL}images/rudro-cutout.webp`} width={900} height={1000} alt="Rudro Roy in a burgundy blazer, black shirt and sunglasses, wearing an event lanyard" fetchPriority="high" />
          </div>
        </div>
      </div>
    </section>
  )
}
