import { useState, type FormEvent, type ReactElement } from 'react'
import { site } from '../data/site'
import { services } from '../data/services'
type Status = 'idle' | 'sending' | 'success' | 'error'
const empty = { name: '', email: '', service: '', details: '' }
export default function Contact() {
  const [f, setF] = useState(empty)
  const [err, setErr] = useState<Record<string, string>>({})
  const [status, setStatus] = useState<Status>('idle')
  const [msg, setMsg] = useState('')
  const c = site.contact
  const links: [string, string, string][] = [
    ['Email', c.email, c.email && `mailto:${c.email}`],
    ['WhatsApp', c.whatsapp, c.whatsapp && `https://wa.me/${c.whatsapp.replace(/\D/g, '')}`],
    ['LinkedIn', c.linkedin, c.linkedin], ['Facebook', c.facebook, c.facebook],
  ]
  const set = (k: keyof typeof empty) => (e: { target: { value: string } }) => setF({ ...f, [k]: e.target.value })
  async function submit(e: FormEvent) {
    e.preventDefault()
    const v: Record<string, string> = {}
    if (f.name.trim().length < 2) v.name = 'Enter your name.'
    if (!/^\S+@\S+\.\S+$/.test(f.email)) v.email = 'Enter a valid email address, like name@example.com.'
    if (!f.service) v.service = 'Choose a service.'
    if (f.details.trim().length < 10) v.details = 'Tell me a little more (at least 10 characters).'
    setErr(v); if (Object.keys(v).length) return
    setStatus('sending')
    try {
      if (site.formEndpoint) {
        const r = await fetch(site.formEndpoint, { method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify(f) })
        if (!r.ok) throw new Error('Request failed')
        setStatus('success'); setMsg('Thanks. Your message was sent and I will reply soon.'); setF(empty)
      } else if (c.email) {
        window.location.href = `mailto:${c.email}?subject=${encodeURIComponent('Project inquiry: ' + f.service)}&body=${encodeURIComponent(`${f.details}\n\n${f.name} (${f.email})`)}`
        setStatus('success'); setMsg('Your email app should open with the message ready. Press send there to finish.')
      } else { setStatus('error'); setMsg('This form is not connected yet. The site owner needs to add an email or form endpoint.') }
    } catch { setStatus('error'); setMsg('The message could not be sent. Check your connection and try again.') }
  }
  const field = (k: keyof typeof empty, label: string, el: ReactElement) => (
    <div className="field"><label htmlFor={k}>{label}</label>{el}{err[k] && <p className="err" id={`${k}-e`} role="alert">{err[k]}</p>}</div>)
  const aria = (k: string) => ({ id: k, 'aria-invalid': !!err[k], 'aria-describedby': err[k] ? `${k}-e` : undefined })
  return (
    <section id="contact" className="sec contact">
      <div className="wrap cgrid">
        <div data-reveal>
          <h2>Have a Project in Mind?</h2>
          <p className="lead">Let's discuss your business goals and explore how digital marketing, creative content, or AI-powered workflows could help.</p>
          <a className="btn" href="#name">Start a Conversation</a>
          <ul className="clinks">{links.map(([n, val, href]) => <li key={n}>{href
            ? <a href={href} target={n === 'Email' ? undefined : '_blank'} rel="noreferrer"><b>{n}</b>{val.startsWith('http') ? (n === 'Facebook' ? 'Rudro Roy' : '') : val}</a>
            : null}</li>)}</ul>
        </div>
        <form className="form" onSubmit={submit} noValidate data-reveal>
          {field('name', 'Name', <input {...aria('name')} value={f.name} onChange={set('name')} autoComplete="name" />)}
          {field('email', 'Email', <input {...aria('email')} type="email" value={f.email} onChange={set('email')} autoComplete="email" />)}
          {field('service', 'Service of interest', <select {...aria('service')} value={f.service} onChange={set('service')}><option value="">Select a service</option>{services.map(s => <option key={s.title}>{s.title}</option>)}</select>)}
          {field('details', 'Project details', <textarea {...aria('details')} rows={5} value={f.details} onChange={set('details')} />)}
          <button className="btn" disabled={status === 'sending'}>{status === 'sending' ? 'Sending…' : 'Send message'}</button>
          <p className={`status ${status}`} role="status">{msg}</p>
        </form>
      </div>
    </section>
  )
}
