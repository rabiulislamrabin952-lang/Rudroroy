import { values, principles } from '../data/site'
export default function About() {
  return (<>
    <section id="about" className="sec">
      <div className="wrap">
        <div data-reveal>
          <p className="label">A LITTLE ABOUT ME</p>
          <h2>Creative Thinking. Strategic Marketing. Smarter Growth.</h2>
          <p className="lead">I combine digital marketing strategy, creative design, and AI-powered workflows to help businesses communicate better, create meaningful content, and build a stronger online presence.</p>
        </div>
        <ol className="vals" data-reveal>
          {values.map((v, i) => <li key={v.title}><span className="num">0{i + 1}</span><h3>{v.title}</h3><p>{v.text}</p></li>)}
        </ol>
      </div>
    </section>
    <section className="sec alt">
      <div className="wrap story">
        <figure className="event" data-reveal>
          <img src={`${import.meta.env.BASE_URL}images/rudro-portrait.jpg`} width={1200} height={1500} loading="lazy" alt="Rudro Roy in a burgundy blazer and white shirt, leaning on a rooftop railing" />
        </figure>
        <div data-reveal>
          <p className="label">BEHIND THE WORK</p>
          <h2>Building Skills. Creating Value. Growing Every Day.</h2>
          <p className="lead">I'm Rudro Roy, a digital marketing and AI-focused creative professional. I enjoy combining strategy, design, and emerging technology to solve digital communication challenges.</p>
          <p className="lead">My goal is to help businesses present themselves more effectively online while continuously improving my skills, creative thinking, and problem-solving approach.</p>
          <ul className="chips">{principles.map(p => <li key={p}>{p}</li>)}</ul>
        </div>
      </div>
    </section>
  </>)
}
